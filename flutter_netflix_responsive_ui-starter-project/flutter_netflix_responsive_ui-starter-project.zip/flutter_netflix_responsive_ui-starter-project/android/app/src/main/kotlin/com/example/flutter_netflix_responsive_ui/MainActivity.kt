package com.example.flutter_netflix_responsive_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
